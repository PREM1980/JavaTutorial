package com.test.rest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;

public class RestClient {
	public static void main(String[] args) throws FileNotFoundException {
		Client client = Client.create();
		WebResource resource = client
				.resource("http://localhost:8080/RESTFileUpload/rest/file/upload");
		String filename = "C:/maven/README.txt";
		InputStream inpstream = new FileInputStream(filename);
		FormDataMultiPart form = new FormDataMultiPart();
		form.field("username", "test");
		form.field("password", "password");
		form.field("filename", "testfile1");
		FormDataBodyPart fdp = new FormDataBodyPart("filecontent",
                inpstream, MediaType.APPLICATION_OCTET_STREAM_TYPE);
		form.bodyPart(fdp);
		ClientResponse response = resource.type(MediaType.MULTIPART_FORM_DATA).post(ClientResponse.class, form);
		
		if (response.getStatus() != 200){
			throw new RuntimeException("Failed request =  " + response.getStatus());
		}
		String output = response.getEntity(String.class);
		System.out.println(output);
	}
}
